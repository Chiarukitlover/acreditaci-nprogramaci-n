# AUSTRA TECH – Sitio web

HTML5 / CSS3 / JS + Node.js (Express) + MySQL (XAMPP).

Estructura: un solo `index.html` (Inicio, Nosotros, Servicios, Contacto y panel admin), un solo `css/styles.css` y `js/main.js`.

## Puesta en marcha
1. Abrir XAMPP y iniciar **MySQL**.
2. En phpMyAdmin, importar `austratech.sql` (o correr los `ALTER` del final si las tablas ya existen).
3. `npm install`
4. `node crear-admin.js <usuario> <clave>` (crea el admin con la clave encriptada)
5. `node server.js` y abrir http://localhost:3000
6. Panel admin: clic en el logo (zona izquierda del header) o `http://localhost:3000/#admin`
