const $ = (id) => document.getElementById(id);

/* ================= NAVEGACIÓN (una sola página) ================= */
const menuBtn = $('menuBtn');
const menu = $('menu');
menuBtn.addEventListener('click', () => menu.classList.toggle('abierto'));
menu.addEventListener('click', (e) => { if (e.target.tagName === 'A') menu.classList.remove('abierto'); });

function ruta() {
  const hash = location.hash.slice(1);
  const esAdmin = hash === 'admin';
  $('sitio').hidden = esAdmin;
  $('vistaAdmin').hidden = !esAdmin;
  menu.hidden = esAdmin;
  if (esAdmin) {
    const logueado = !!sessionStorage.getItem('token');
    mostrarPanel(logueado);
    if (logueado) cargar();
    window.scrollTo(0, 0);
  } else {
    $('btnSalir').hidden = true;
    if (hash) { const el = $(hash); if (el) el.scrollIntoView(); }
  }
}
window.addEventListener('hashchange', ruta);

// Resalta en el menú la sección visible
const secciones = document.querySelectorAll('main#sitio section[id]');
const links = document.querySelectorAll('#menu a');
const observador = new IntersectionObserver((entradas) => {
  entradas.forEach(en => {
    if (!en.isIntersecting) return;
    links.forEach(a => a.classList.toggle('activo', a.getAttribute('href') === '#' + en.target.id));
  });
}, { rootMargin: '-40% 0px -55% 0px' });
secciones.forEach(s => observador.observe(s));

/* ================= FORMULARIO DE CONSULTAS ================= */
const form = $('formContacto');
const alerta = $('alerta');
const f = form.elements;

function setError(input, texto) {
  const campo = input.closest('.campo');
  campo.classList.toggle('error', !!texto);
  campo.querySelector('.msg-error').textContent = texto || '';
  return !texto;
}

function validar() {
  let ok = true;
  ok = setError(f.tipoconsulta, f.tipoconsulta.value ? '' : 'Elegí un tipo de consulta') && ok;
  const c = f.contacto.value.trim();
  const contactoOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c) || /^[\d\s()+\-]{6,25}$/.test(c);
  ok = setError(f.contacto, contactoOk ? '' : 'Ingresá un email o teléfono válido') && ok;
  const largo = f.consulta.value.trim().length;
  ok = setError(f.consulta, largo >= 10 && largo <= 500 ? '' : 'La consulta debe tener entre 10 y 500 caracteres') && ok;
  return ok;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  alerta.className = 'alerta';
  if (!validar()) return;
  try {
    const r = await fetch('/api/consultas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tipoconsulta: f.tipoconsulta.value,
        contacto: f.contacto.value.trim(),
        consulta: f.consulta.value.trim()
      })
    });
    const data = await r.json();
    alerta.textContent = r.ok ? '¡Consulta enviada! Te respondemos a la brevedad.' : (data.mensaje || 'No se pudo enviar.');
    alerta.className = r.ok ? 'alerta ok' : 'alerta mal';
    if (r.ok) form.reset();
  } catch {
    alerta.textContent = 'No hay conexión con el servidor. Probá de nuevo.';
    alerta.className = 'alerta mal';
  }
});

/* ================= PANEL DE ADMINISTRACIÓN ================= */
let consultas = [];

function aviso(el, texto, ok) { el.textContent = texto; el.className = 'alerta ' + (ok ? 'ok' : 'mal'); }

// fetch con token; si la sesión venció vuelve al login
async function api(url, opciones = {}) {
  const r = await fetch(url, {
    ...opciones,
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sessionStorage.getItem('token') }
  });
  if (r.status === 401) { salir('Tu sesión expiró. Volvé a ingresar.'); throw new Error('401'); }
  return r;
}

function mostrarPanel(si) {
  $('vistaLogin').hidden = si;
  $('vistaPanel').hidden = !si;
  $('btnSalir').hidden = !si;
}

function salir(msg) {
  sessionStorage.removeItem('token');
  mostrarPanel(false);
  if (msg) aviso($('alertaLogin'), msg, false);
}

$('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const r = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario: $('usuario').value.trim(), clave: $('clave').value })
    });
    const data = await r.json();
    if (!r.ok) return aviso($('alertaLogin'), data.mensaje || 'No se pudo ingresar', false);
    sessionStorage.setItem('token', data.token);
    $('formLogin').reset();
    $('alertaLogin').className = 'alerta';
    mostrarPanel(true);
    cargar();
  } catch { aviso($('alertaLogin'), 'Error de conexión con el servidor', false); }
});

$('btnSalir').addEventListener('click', () => { salir(); location.hash = '#inicio'; });
$('filtro').addEventListener('change', dibujar);

async function cargar() {
  try {
    const r = await api('/api/consultas');
    consultas = await r.json();
    dibujar();
  } catch {}
}

function dibujar() {
  const filtro = $('filtro').value;
  const lista = $('lista');
  lista.innerHTML = '';
  const visibles = consultas.filter(c => filtro === 'todas' || (filtro === 'atendidas') === !!c.respuesta);
  if (!visibles.length) { lista.textContent = 'No hay consultas para mostrar.'; return; }

  visibles.forEach(c => {
    const d = document.createElement('div');
    d.className = 'fila-consulta' + (c.respuesta ? ' atendida' : '');

    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = `#${c.id_consultas} · ${c.tipoconsulta} · ${c.contacto}` +
      (c.fecha_atencion ? ' · atendida ' + new Date(c.fecha_atencion).toLocaleString('es-AR') : ' · pendiente');

    const txt = document.createElement('p');
    txt.textContent = c.consulta;            // textContent evita inyectar HTML

    const area = document.createElement('textarea');
    area.rows = 3; area.maxLength = 500; area.placeholder = 'Escribí tu respuesta...';
    area.value = c.respuesta || '';

    const acc = document.createElement('div');
    acc.className = 'acciones';
    const bg = document.createElement('button');
    bg.className = 'btn chico'; bg.textContent = 'Guardar respuesta';
    bg.onclick = () => guardar(c.id_consultas, area.value);
    const be = document.createElement('button');
    be.className = 'btn chico secundario'; be.textContent = 'Eliminar';
    be.onclick = () => eliminar(c.id_consultas);
    acc.append(bg, be);

    d.append(meta, txt, area, acc);
    lista.appendChild(d);
  });
}

async function guardar(id, respuesta) {
  try {
    const r = await api('/api/atencion', { method: 'POST', body: JSON.stringify({ id_consultas: id, respuesta }) });
    const data = await r.json();
    aviso($('alertaPanel'), data.mensaje, r.ok);
    if (r.ok) cargar();
  } catch {}
}

async function eliminar(id) {
  if (!confirm('¿Eliminar esta consulta?')) return;
  try {
    const r = await api('/api/consultas/' + id, { method: 'DELETE' });
    const data = await r.json();
    aviso($('alertaPanel'), data.mensaje, r.ok);
    if (r.ok) cargar();
  } catch {}
}

ruta();
